from rest_framework import serializers
from .models import Book
from django.conf import settings

class BookSerializer(serializers.ModelSerializer):
    image = serializers.SerializerMethodField()

    class Meta:
        model = Book
        fields = ['id', 'title', 'author', 'description', 'category', 'uploaded_by', 'image']

    def get_image(self, obj):
        request = self.context.get('request')
        if obj.image:
            # Return full absolute URL to the image file
            return request.build_absolute_uri(obj.image.url)
        return None
