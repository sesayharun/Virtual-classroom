# Existing DRF imports and views
from rest_framework import viewsets
from .models import Product, Category, Supplier
from .serializers import ProductSerializer, CategorySerializer, SupplierSerializer

class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer

class SupplierViewSet(viewsets.ModelViewSet):
    queryset = Supplier.objects.all()
    serializer_class = SupplierSerializer


# NEW: Django Web Views for Product Management
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

# Web view to list all products
from django.db.models import Q

class ProductListView(ListView):
    model = Product
    template_name = 'inventory/product_list.html'
    context_object_name = 'products'

    def get_queryset(self):
        query = self.request.GET.get('q')
        if query:
            return Product.objects.filter(
                Q(name__icontains=query) |
                Q(description__icontains=query)
            )
        return Product.objects.all()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['search_query'] = self.request.GET.get('q', '')
        return context


# Web view to create a new product
class ProductCreateView(CreateView):
    model = Product
    fields = ['name', 'description', 'price', 'quantity', 'category', 'supplier']
    template_name = 'inventory/product_form.html'
    success_url = reverse_lazy('product_list')

# Web view to update an existing product
class ProductUpdateView(UpdateView):
    model = Product
    fields = ['name', 'description', 'price', 'quantity', 'category', 'supplier']
    template_name = 'inventory/product_form.html'
    success_url = reverse_lazy('product_list')

# Web view to delete a product
class ProductDeleteView(DeleteView):
    model = Product
    template_name = 'inventory/product_confirm_delete.html'
    success_url = reverse_lazy('product_list')
