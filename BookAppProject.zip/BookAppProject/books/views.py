from django.shortcuts import render, redirect, get_object_or_404
from .models import Book
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout
from django.shortcuts import render, redirect, get_object_or_404
from django.shortcuts import render, redirect
from .forms import BookForm
from django.contrib.auth import logout
from django.shortcuts import redirect
from django.shortcuts import render, redirect
from .forms import CustomRegisterForm
from rest_framework import viewsets
from .models import Book
from .serializers import BookSerializer
from rest_framework import generics
from .models import Book
from .serializers import BookSerializer

def home(request):
    category = request.GET.get('category')  # e.g., ?category=Fiction
    if category:
        books = Book.objects.filter(category=category)
    else:
        books = Book.objects.all()
    categories = Book.CATEGORY_CHOICES  # for dropdown
    return render(request, 'home.html', {'books': books, 'categories': categories})

def admin_dashboard(request):
    books = Book.objects.all()
    return render(request, 'books/admin_dashboard.html', {'books': books})

def add_book(request):
    if request.method == 'POST':
        title = request.POST['title']
        author = request.POST['author']
        cover = request.FILES.get('cover')
        Book.objects.create(title=title, author=author, cover=cover)
        return redirect('admin_dashboard')
    return redirect('admin_dashboard')

def edit_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)

    if request.method == 'POST':
        book.title = request.POST.get('title')
        book.author = request.POST.get('author')
        book.description = request.POST.get('description')

        if request.FILES.get('image'):
            book.image = request.FILES['image']

        book.save()
        return redirect('admin_dashboard')

    return render(request, 'edit_book.html', {'book': book})

def delete_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    book.delete()
    return redirect('admin_dashboard')

@login_required
def book_detail(request, pk):
    book = get_object_or_404(Book, pk=pk)
    return render(request, 'books/book_detail.html', {'book': book})

def login_view(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            auth_login(request, user)
            if user.is_superuser:
                return redirect('admin_dashboard')
            else:
                return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'books/login.html', {'form': form})


def register_view(request):
    if request.method == 'POST':
        form = CustomRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = CustomRegisterForm()
    return render(request, 'register.html', {'form': form})

@login_required
def admin_dashboard(request):
    if not request.user.is_superuser:
        return redirect('home')
    books = Book.objects.all()
    return render(request, 'books/admin_dashboard.html', {'books': books})

def logout_view(request):
    logout(request)
    return redirect('landing')

def upload_book(request):
    if request.method == 'POST':
        title = request.POST['title']
        author = request.POST['author']
        description = request.POST['description']
        category = request.POST['category']
        image = request.FILES['image']
        uploaded_by = request.user

        Book.objects.create(
            title=title,
            author=author,
            description=description,
            category=category,
            image=image,
            uploaded_by=uploaded_by
        )
        return redirect('admin_dashboard')

def landing_page(request):
    featured_book = Book.objects.order_by('-id').first()  
    return render(request, 'landing.html', {'featured_book': featured_book})


class BookViewSet(viewsets.ModelViewSet):
    queryset = Book.objects.all()
    serializer_class = BookSerializer

# books/api_views.py

class BookListCreateAPIView(generics.ListCreateAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer

class BookRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer

def get_image(self, obj):
    request = self.context.get('request')
    if obj.image:
        return request.build_absolute_uri(obj.image.url)
    return request.build_absolute_uri('/path/to/default/image.jpg')  # or None
